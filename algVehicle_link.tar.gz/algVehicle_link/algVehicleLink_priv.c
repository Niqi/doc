/*******************************************************************************
 *                                                                             *
 * Copyright (c) 2009 Texas Instruments Incorporated - http://www.ti.com/      *
 *                        ALL RIGHTS RESERVED                                  *
 *                                                                             *
 ******************************************************************************/

#include "algVehicleLink_priv.h"
#include <mcfw/src_bios6/utils/utils_mem.h>

#define UTILS_ALGVEHICLE_GET_OUTBUF_SIZE()   (sizeof(AlgVehicleLink_ThPlateIdResult))


static Int32 AlgVehicleLink_createOutObj(AlgVehicleLink_Obj * pObj)
{
    AlgVehicleLink_OutObj *pOutObj;
    System_LinkChInfo *pOutChInfo;
    Int32 status;
    UInt32 bufIdx;
    Int i,j,queueId,chId;
    UInt32 totalBufCnt;

    for(queueId = 0; queueId < ALGVEHICLE_LINK_MAX_OUT_QUE; queueId++)
    {

        pOutObj = &pObj->outObj[queueId];    

        pObj->outObj[queueId].numAllocPools = 1;

        pOutObj->buf_size[0] = UTILS_ALGVEHICLE_GET_OUTBUF_SIZE();
        pOutObj->buf_size[0] = VpsUtils_align(pOutObj->buf_size[0], ALGVEHICLE_BUFFER_ALIGNMENT);

        status = Utils_bitbufCreate(&pOutObj->bufOutQue, TRUE, FALSE,
                                    pObj->outObj[queueId].numAllocPools);
        UTILS_assert(status == FVID2_SOK);

        totalBufCnt = 0;
        for (i = 0; i < pOutObj->numAllocPools; i++)
        {
            pOutObj->outNumBufs[i] = (pObj->thPlateIdAlg.createArgs.numValidChForTHPLATEID * pObj->thPlateIdAlg.createArgs.numBufPerCh);

            for (j = 0; j < pObj->thPlateIdAlg.createArgs.numValidChForTHPLATEID; j++)
            {
                pOutObj->ch2poolMap[j] =  i;
            }

            status = Utils_memBitBufAlloc(&(pOutObj->outBufs[totalBufCnt]),
                                          pOutObj->buf_size[i],
                                          pOutObj->outNumBufs[i]);
            UTILS_assert(status == FVID2_SOK);

            for (bufIdx = 0; bufIdx < pOutObj->outNumBufs[i]; bufIdx++)
            {
                UTILS_assert((bufIdx + totalBufCnt) < ALGVEHICLE_LINK_THPLATEID_MAX_OUT_FRAMES);
                pOutObj->outBufs[bufIdx + totalBufCnt].allocPoolID = i;
                pOutObj->outBufs[bufIdx + totalBufCnt].doNotDisplay =
                    FALSE;
                status =
                    Utils_bitbufPutEmptyBuf(&pOutObj->bufOutQue,
                                            &pOutObj->outBufs[bufIdx +
                                                              totalBufCnt]);
                UTILS_assert(status == FVID2_SOK);
            }
            /* align size to minimum required frame buffer alignment */
            totalBufCnt += pOutObj->outNumBufs[i];
        }
    }
    pObj->info.numQue = ALGVEHICLE_LINK_MAX_OUT_QUE;

    for (queueId = 0u; queueId < ALGVEHICLE_LINK_MAX_OUT_QUE; queueId++)
    {
        pObj->info.queInfo[queueId].numCh = pObj->inQueInfo.numCh;
    }

    for (chId = 0u; chId < pObj->inQueInfo.numCh; chId++)
    {
        for (queueId = 0u; queueId < ALGVEHICLE_LINK_MAX_OUT_QUE; queueId++)
        {
            pOutChInfo = &pObj->info.queInfo[queueId].chInfo[chId];
            pOutChInfo->bufType = SYSTEM_BUF_TYPE_VIDBITSTREAM;
            pOutChInfo->codingformat = NULL;
            pOutChInfo->memType = NULL;
            pOutChInfo->scanFormat = pObj->inQueInfo.chInfo[chId].scanFormat;
            pOutChInfo->width = pObj->inQueInfo.chInfo[chId].width;
            pOutChInfo->height = pObj->inQueInfo.chInfo[chId].height;
        }
    }

    
    return (status);
}



Int32 AlgVehicleLink_algCreate(AlgVehicleLink_Obj * pObj, AlgVehicleLink_CreateParams * pPrm)
{
    Int32 status;

    Vps_printf(" %d: ALGVEHICLE : algCreate in progress !!!\n", Utils_getCurTimeInMsec());

    UTILS_MEMLOG_USED_START();
    memcpy(&pObj->thPlateIdAlg.createArgs, &pObj->createArgs.thPlateIdCreateParams, sizeof(AlgVehicleLink_ThPlateIdCreateParams));

    System_getEdmaCh(&pObj->copyEdmaHndlYplane);	
    System_getEdmaCh(&pObj->copyEdmaHndlUVplane);

    pObj->thPlateIdAlg.inQueInfo = &pObj->inQueInfo;

    if (pObj->createArgs.enableThPlateIdAlg)
    {
        status = AlgVehicleLink_ThPlateIdalgCreate(&pObj->thPlateIdAlg);
        UTILS_assert(status == FVID2_SOK);
        AlgVehicleLink_createOutObj(pObj);
    }    

    UTILS_MEMLOG_USED_END(pObj->memUsed);
    UTILS_MEMLOG_PRINT("ALGVEHICLE",
                       pObj->memUsed,
                       UTILS_ARRAYSIZE(pObj->memUsed));
    Vps_printf(" %d: ALGVEHICLE: algCreate Done !!!\n", Utils_getCurTimeInMsec());
    return FVID2_SOK;
}

Int32 AlgVehicleLink_algDelete(AlgVehicleLink_Obj * pObj)
{    
    Int32 status;

    Vps_printf(" %d: ALGVEHICLE : algDelete in progress !!!\n", Utils_getCurTimeInMsec());
    
    if (pObj->createArgs.enableThPlateIdAlg)
    {
        status = AlgVehicleLink_ThPlateIdalgDelete(&pObj->thPlateIdAlg);
        UTILS_assert(status == FVID2_SOK);
    }
    
    Vps_printf(" %d: ALGVEHICLE : algDelete Done !!!\n", Utils_getCurTimeInMsec());

	return FVID2_SOK;
}

Int32 AlgVehicleLink_algProcessData(AlgVehicleLink_Obj * pObj)
{
    UInt32 status = FVID2_SOK;
	Int32 procesFrames = 0;	
    AlgVehicleLink_ThPlateIdObj * pAlgObj;
    FVID2_Frame *pEmptyFrame, *pFullFrame;     
    UInt64 start,end;
    //AlgVehicleLink_perFrameConfig* pFrameFrameCfg;

    pAlgObj = &pObj->thPlateIdAlg;

    do
    {
    	Vps_rprintf("%s %d\n",__FUNCTION__,__LINE__);
        /* Get the frame from the full queue */
        status = Utils_bufGetFullFrame(&pObj->processFrameQue, &pFullFrame, BIOS_NO_WAIT);

        if ((status == FVID2_SOK) && (pFullFrame != NULL))
        {
        	Vps_rprintf("%s %d\n",__FUNCTION__,__LINE__);
            /* statist process time start */
            start = Utils_getCurTimeInUsec();

            /* pro */
            /* THPLATEID ALG */
            if (pObj->createArgs.enableThPlateIdAlg)
            {
                //pFrameFrameCfg = (AlgVehicleLink_perFrameConfig*)(pFullFrame->perFrameCfg);
                if(1)
                {
                	status = AlgVehicleLink_ThPlateIdalgProcessData(pAlgObj, pFullFrame, &pObj->outObj[0].bufOutQue);
                }
                //Vps_printf("niqi_debug:algProcess :%d\n", pFrameFrameCfg->bufId);
                if (status == FVID2_SOK)
                {
#if 0            
                    /* Send-out the output bitbuffer */
                    System_sendLinkCmd(pObj->createArgs.outQueParams.nextLink,
                                       SYSTEM_CMD_NEW_DATA);
#endif
                }
            }  

            if(0)
            {                              
                System_linkControl(SYSTEM_LINK_ID_HOST, SYSTEM_COMMON_VEHICLE_ALG_RESULT, 
                                                    &pAlgObj->chObj[0].thPlateIdResult, sizeof(THPLATEIDALG_Result), FALSE);
            }
         
            /* statist process time end */
            end = Utils_getCurTimeInUsec();
            if((end - start) > pAlgObj->chObj[0].maxProcessTime)
            {
                pAlgObj->chObj[0].maxProcessTime = (end - start);
            }
            pAlgObj->chObj[0].totalProcessTime += (end - start);
            pAlgObj->chObj[0].processFrCnt ++;
            pAlgObj->chObj[0].totalFrameCount++;
			
			if(1)//(pAlgObj->chObj[0].thPlateIdResult.thPlateIdResultAll[0].nColor >= 0)
			{
		        Vps_printf("\n THPLATEIDALG: Process frame, numVeh:%d, sn:%s, cl:%d, tp:%d, tm:%ld \n", 
		                        pAlgObj->chObj[0].thPlateIdResult.nNumberOfVehicle, 
		                        pAlgObj->chObj[0].thPlateIdResult.thPlateIdResultAll[0].license, 
		                        pAlgObj->chObj[0].thPlateIdResult.thPlateIdResultAll[0].nColor, 
		                        pAlgObj->chObj[0].thPlateIdResult.thPlateIdResultAll[0].nConfidence,
		                        (end - start)/1000);			
			}
            //Vps_printf("ALGVEHICLE   :process_tv %ldms \n", (end - start)/1000);
            if(pAlgObj->chObj[0].processFrCnt >= 200)
            {
                Vps_printf(" %d: ALGVEHICLE: alg Avg Prc tm = %ld us/f, max:%ld !!!\n",
            			   Clock_getTicks(), pAlgObj->chObj[0].totalProcessTime/pAlgObj->chObj[0].processFrCnt,
            			   pAlgObj->chObj[0].maxProcessTime);	   
                pAlgObj->chObj[0].processFrCnt     = 0;
                pAlgObj->chObj[0].totalProcessTime = 0;
            } 

            status = Utils_bufPutFullFrame(&pObj->outFrameQue,pEmptyFrame);
            UTILS_assert(status == FVID2_SOK);  
			procesFrames++;
        }
    } while ((status == FVID2_SOK) && (pFullFrame != NULL));

	if(procesFrames){
	    /* send SYSTEM_CMD_NEW_DATA to next link */
		Vps_rprintf("%s %d\n",__FUNCTION__,__LINE__);
	    System_sendLinkCmd(pObj->createArgs.outQueParams.nextLink, SYSTEM_CMD_NEW_DATA);
	}	
        
    return FVID2_SOK;
}


/* AlgVehicle link copy frames */

/* ===================================================================
 *  @func     AlgVehicleLink_algCopyFrames
 *
 *  @desc     Function does the following
 *
 *  @modif    This function modifies the following structures
 *
 *  @inputs   This function takes the following inputs
 *            <argument name>
 *            Description of usage
 *            <argument name>
 *            Description of usage
 *
 *  @outputs  <argument name>
 *            Description of usage
 *
 *  @return   Return value of this function if any
 *  ==================================================================
 */
static UInt64 start = 0;
static UInt64 end = 0;
Int32 AlgVehicleLink_algCopyFrames(AlgVehicleLink_Obj *pObj)
{
    Int32 status = FVID2_SOK;
    Int32 frameId;
    UInt32 edmaWidth, edmaHeight, edmaSrcOffset;
    FVID2_Frame *pEmptyFrame;
    FVID2_Frame *pFullFrame;
    FVID2_FrameList frameList;
    System_LinkInQueParams *pInQueParams;
    AlgVehicleLink_ThPlateIdObj *pAlgObj = &pObj->thPlateIdAlg;

    /* Get the full frames from the previous link */
    pInQueParams = &pObj->createArgs.inQueParams;

    System_getLinksFullFrames(pInQueParams->prevLinkId,
                              pInQueParams->prevLinkQueId, &frameList);
	//Vps_rprintf("%s %d\n",__FUNCTION__,__LINE__);

    if (frameList.numFrames)
    {
        for (frameId = 0; frameId < frameList.numFrames; frameId++)
        {
        	//Vps_rprintf("%s %d\n",__FUNCTION__,__LINE__);
            if(Utils_doSkipFrame(&pAlgObj->chObj[0].frameSkipCtx) == FALSE)
            {
            	//Vps_rprintf("%s %d\n",__FUNCTION__,__LINE__);
                /* Get the AlgVehicle empty bufs if any */
#ifdef ALG_NO_PROCESS
				status = Utils_bufGetEmptyFrame(&pObj->outFrameQue, &pEmptyFrame, BIOS_NO_WAIT);
#else
                status = Utils_bufGetEmptyFrame(&pObj->processFrameQue, &pEmptyFrame, BIOS_NO_WAIT);
#endif
				Vps_rprintf("%s %d %d 0x%08x\n",__FUNCTION__,__LINE__, status, &pObj->outFrameQue);
                if ((status == FVID2_SOK) && (pEmptyFrame != NULL))
                {
                	Vps_rprintf("%s %d\n",__FUNCTION__,__LINE__);
                	end = start;
                	start = Utils_getCurTimeInUsec();
					if(0)
					{
						Vps_printf("Utils_bufGetEmptyFrame time %ld \n", (start - end)/1000);
					}
                    pFullFrame = frameList.frames[frameId];

                    /* copy the Yframe */
                    edmaWidth  = pObj->inQueInfo.chInfo[0].width;
                    edmaHeight = pObj->inQueInfo.chInfo[0].height;
                    edmaSrcOffset = pObj->inQueInfo.chInfo[0].pitch[0];

                    /* copy Y plane */
                    DM81XX_EDMA3_setParams(pObj->copyEdmaHndlYplane.dmaHndl.chId, 		// chId
                    					   ALGVEHICLE_LINK_EDMA3_QUEUE_ID_0,  			// dmaQueue
                    					   (UInt32)pFullFrame->addr[0][0], 				// srcAddr
                    					   (UInt32)pEmptyFrame->addr[0][0],				// dstAddr
                    					   edmaWidth,          							// edmaWidth
                    					   edmaHeight,					                    // edmaHeight
                    					   edmaSrcOffset,          							// srcLineOffset
                    					   edmaWidth);         							// dstLineOffset
                    /* Trigger the edma transfer */
                    DM81XX_EDMA3_triggerTransfer(pObj->copyEdmaHndlYplane.dmaHndl.chId,
                    								(UInt32)pEmptyFrame->addr[0][0],
                    								edmaWidth,
													edmaHeight);

					/* copy UV plane */
                    DM81XX_EDMA3_setParams(pObj->copyEdmaHndlUVplane.dmaHndl.chId, 		// chId
                    					   ALGVEHICLE_LINK_EDMA3_QUEUE_ID_0,  			// dmaQueue
                    					   (UInt32)pFullFrame->addr[0][1], 				// srcAddr
                    					   (UInt32)pEmptyFrame->addr[0][1],				// dstAddr
                    					   edmaWidth,          							// edmaWidth
                    					   edmaHeight/2,         							// edmaHeight
                    					   edmaSrcOffset,          							// srcLineOffset
                    					   edmaWidth);         							// dstLineOffset
                                 

                    /* Trigger the edma transfer */
                    DM81XX_EDMA3_triggerTransfer(pObj->copyEdmaHndlUVplane.dmaHndl.chId,
                    								(UInt32)pEmptyFrame->addr[0][0],
                    								edmaWidth,
													edmaHeight/2);                 

                    pEmptyFrame->timeStamp = pFullFrame->timeStamp;

                    /* put the buffer into full queue */
#ifdef ALG_NO_PROCESS
					status = Utils_bufPutFullFrame(&pObj->outFrameQue, pEmptyFrame);
#else					
                    status = Utils_bufPutFullFrame(&pObj->processFrameQue, pEmptyFrame);
#endif
                    UTILS_assert(status == FVID2_SOK);
                }
            }
        }

#ifdef ALG_NO_PROCESS
		System_sendLinkCmd(pObj->createArgs.outQueParams.nextLink,SYSTEM_CMD_NEW_DATA);
#endif		

        /* Put the full buffers bacl to previous link */
        System_putLinksEmptyFrames(pInQueParams->prevLinkId,
                                   pInQueParams->prevLinkQueId, &frameList);
    }

	Vps_rprintf("%s %d %d\n",__FUNCTION__,__LINE__, status);	
    return status;
}


